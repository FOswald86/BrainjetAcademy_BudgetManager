package budget;

public enum Category {
    Food, Entertainment, Clothes, Other, All
}